function loadData() {
    var oXHR = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');

    function reportStatus() {
        if (oXHR.readyState == 4) // REQUEST COMPLETED.
            showTheList(this.responseXML); // ALL SET. NOW SHOW XML DATA.
    }

    oXHR.onreadystatechange = reportStatus;
    oXHR.open("GET", "TW-G03.xml", true); // true = ASYNCHRONOUS REQUEST (DESIRABLE), false = SYNCHRONOUS REQUEST.
    oXHR.send();
}

function showTheList(xml) {

    var divBooks = document.getElementById('library'); // THE PARENT DIV.
    var Book_List = xml.getElementsByTagName('List'); // THE XML TAG NAME.

    for (var i = 0; i < Book_List.length; i++) {

        // CREATE CHILD DIVS INSIDE THE PARENT DIV.
        var divLeft = document.createElement('div');
        divLeft.className = 'col_esquerda';
        divLeft.innerHTML = Book_List[i].getElementsByTagName("Vehicle")[0].childNodes[0].nodeValue;

        var divRight = document.createElement('div');
        divRight.className = 'col_direita';
        divRight.innerHTML = Book_List[i].getElementsByTagName("Price")[0].childNodes[0].nodeValue;

        // ADD THE CHILD TO THE PARENT DIV.
        divBooks.appendChild(divLeft);
        divBooks.appendChild(divRight);
    }
};